namespace omega {
#if ! defined List
#define List Omega_List
#define List_Iterator Omega_List_Iterator
#endif
}
