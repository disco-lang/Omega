namespace omega {
#undef Iterator
#undef Any_Iterator
#undef Generator
}
