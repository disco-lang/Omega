namespace omega {
#if ! defined Iterator
#define Iterator Omega_Iterator
#define Any_Iterator Omega_Any_Iterator
#define Generator Omega_Generator
#endif
}
