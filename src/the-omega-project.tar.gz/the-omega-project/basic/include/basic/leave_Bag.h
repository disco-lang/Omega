namespace omega {
#undef Bag
#undef Ordered_Bag
#undef Set
}
