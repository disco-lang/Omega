namespace omega {
#if ! defined enter_String_h
#define String omega::String
#endif
}
