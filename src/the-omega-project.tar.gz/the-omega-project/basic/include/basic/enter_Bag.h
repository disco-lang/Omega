namespace omega {
#if ! defined Bag
#define Bag Omega_Bag
#define Ordered_Bag Omega_Ordered_Bag
#define Set Omega_Set
#endif
}
