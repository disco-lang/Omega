#if ! defined _Bool_h
#define _Bool_h 1

#ifdef __SUNPRO_CC

#define bool	int
#define true	1
#define false	0

#endif

#endif
