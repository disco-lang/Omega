#if ! defined Already_Included_Omega_Library_Version
#define Already_Included_Omega_Library_Version 1

#define Omega_Library_Major_Version  2
#define Omega_Library_Minor_Version  1

#define Omega_Library_Version "Omega Library 2.1"
#define Omega_Library_Date "July, 2008"

#endif
